The following files were generated for 'chipscope_icon_1' in directory
D:\Xilinx_prj\SATAphy3a7\ipcore_dir\

XCO file generator:
   Generate an XCO file for compatibility with legacy flows.

   * chipscope_icon_1.xco

Creates an implementation netlist:
   Creates an implementation netlist for the IP.

   * chipscope_icon_1.constraints/chipscope_icon_1.ucf
   * chipscope_icon_1.constraints/chipscope_icon_1.xdc
   * chipscope_icon_1.ngc
   * chipscope_icon_1.ucf
   * chipscope_icon_1.vhd
   * chipscope_icon_1.vho
   * chipscope_icon_1.xdc
   * chipscope_icon_1_xmdf.tcl

IP Symbol Generator:
   Generate an IP symbol based on the current project options'.

   * chipscope_icon_1.asy

SYM file generator:
   Generate a SYM file for compatibility with legacy flows

   * chipscope_icon_1.sym

Generate ISE subproject:
   Create an ISE subproject for use when including this core in ISE designs

   * chipscope_icon_1.gise
   * chipscope_icon_1.xise

Deliver Readme:
   Readme file for the IP.

   * chipscope_icon_1_readme.txt

Generate FLIST file:
   Text file listing all of the output files produced when a customized core was
   generated in the CORE Generator.

   * chipscope_icon_1_flist.txt

Please see the Xilinx CORE Generator online help for further details on
generated files and how to use them.

