The following files were generated for 'sata_ibert' in directory
D:\Xilinx_prj\SATAphy3v6\ipcore_dir\

XCO file generator:
   Generate an XCO file for compatibility with legacy flows.

   * sata_ibert.xco

Creates an implementation netlist:
   Creates an implementation netlist for the IP.

   * example_sata_ibert.bit
   * example_sata_ibert.map.mrp
   * example_sata_ibert.map.pcf
   * example_sata_ibert.ncd
   * example_sata_ibert.pad
   * example_sata_ibert.pad.csv
   * example_sata_ibert.pad.txt
   * sata_ibert/example_design/example_sata_ibert.vhd
   * sata_ibert/example_design/sata_ibert_top.ucf
   * sata_ibert/implement/chipscope_icon_1.xco
   * sata_ibert/implement/coregen.cgp
   * sata_ibert/implement/example_implement_sata_ibert.prj
   * sata_ibert/implement/example_implement_sata_ibert.xst
   * sata_ibert/implement/implement.bat
   * sata_ibert/implement/implement.sh
   * sata_ibert.gts
   * sata_ibert.ngc
   * sata_ibert.vhd
   * sata_ibert.vho
   * vivado_sata_ibert.ngc

Creates an HDL instantiation template:
   Creates an HDL instantiation template for the IP.

   * sata_ibert.vho

IP Symbol Generator:
   Generate an IP symbol based on the current project options'.

   * sata_ibert.asy

SYM file generator:
   Generate a SYM file for compatibility with legacy flows

   * sata_ibert.sym

Generate ISE metadata:
   Create a metadata file for use when including this core in ISE designs

   * sata_ibert_xmdf.tcl

Generate ISE subproject:
   Create an ISE subproject for use when including this core in ISE designs

   * _xmsgs/pn_parser.xmsgs
   * sata_ibert.gise
   * sata_ibert.xise

Deliver Readme:
   Readme file for the IP.

   * sata_ibert_readme.txt

Generate FLIST file:
   Text file listing all of the output files produced when a customized core was
   generated in the CORE Generator.

   * sata_ibert_flist.txt

Please see the Xilinx CORE Generator online help for further details on
generated files and how to use them.

